
onmessage = function(e) {
	
    var msg = e.data ;
    var n = parseInt(msg);
     
    let i=0,ans=1;
    var str="";

    for(i=n;i>0;i--){

        ans=1;

        for(j=i;j>0;j--){
            ans*=j;
        }

        str = str + i +" ! = "+ ans+ "<br>";
        console.log(str);

    }
    
    
    postMessage(str);
    
};    


