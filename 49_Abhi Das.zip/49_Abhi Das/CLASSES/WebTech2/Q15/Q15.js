var loginRegex = /^[a-zA-Z_0-9]{4,20}$/;
var nameRegex = /^[a-zA-Z ]{1,70}$/;
var contactRegex = /^[1-9]{1,1}[0-9]{9,9}$/;

var res = document.getElementById('result');

function checkPassword(pass){
	if (pass.length < 8) {
        res.innerHTML = "<p style=\"color: red\">Your password must be at least 8 characters</p>"; 
        return false;
    }
    if (pass.search(/[a-z]/i) < 0) {
        res.innerHTML = "<p style=\"color: red\">Your password must contain at least one letter.</p>";
        return false;
    }
    if (pass.search(/[0-9]/) < 0) {
        res.innerHTML = "<p style=\"color: red\">Your password must contain at least one digit.</p>";
        return false; 
    }
    if(pass.search(/[A-Z]/) < 0){
    	res.innerHTML = "<p style=\"color: red\">Your password must contains atleast one uppercase character</p>";
    	return false;
    }
    return true;
}

document.getElementById('submitForm').addEventListener('click', function(e){
	e.preventDefault();
	res.innerHTML = "";

	var login = document.getElementById("login").value;
	var password = document.getElementById("password").value;
	var rPassword = document.getElementById("r-password").value;
	var email = document.getElementById("email").value;
	var contact = document.getElementById("contact").value;
	var name = document.getElementById("name").value;


	// check the details entered by user
	if(password !== rPassword){
		res.innerHTML = "<p style=\"color: red\">Password doesn't match!</p>";
		return;
	}
	if(!nameRegex.test(name)){
		res.innerHTML = "<p style=\"color: red\">Name must contains only alphabets</p>";
		return;
	}
	if(!loginRegex.test(login)){
		res.innerHTML = "<p style=\"color: red\">Login field must be atleast 4 characters long and can contains only alphanumeric characters along with '_'</p>";
		return;
	}
	if(!contactRegex.test(contact)){
		res.innerHTML = "<p style=\"color: red\">please enter a valid contact number!</p>";
		return;
	}

	if(password !== rPassword){
		res.innerHTML = "<p style=\"color: red;\">Password doesn't match!</p>";
		return;
	}
	if(!checkPassword(password)) return;

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function(){
		if(this.readyState === 4 && this.status === 200){
			// success and response is received
			res.innerHTML = this.responseText;
		}
	}
	xhttp.open("POST", "Q15.jsp", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
	str = 'login=' + login + "&password=" + password + "&email=" + email + "&contact=" + contact + "&name=" + name;
	
	console.log(str);
	
	xhttp.send('login=' + login + "&password=" + password + "&email=" + email + "&contact=" + contact + "&name=" + name);
});
