// build the users table and registers some user in ques22

document.getElementById("submitQuery").addEventListener('click', function(e){
	e.preventDefault();

	var login = document.getElementById("login").value;
	var password  = document.getElementById("password").value;

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function(){
		if(this.readyState === 4 && this.status === 200){
			// success and response is received
			document.getElementById("queryResult").innerHTML = this.responseText;
		}
	}
	xhttp.open("POST", "Q7.jsp", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
	xhttp.send('login=' + login + '&password=' + password);
});