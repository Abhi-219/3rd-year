document.getElementById("submitQuery").addEventListener('click', function (e) {
	e.preventDefault();

	var login = document.getElementById("login").value;
	var pass = document.getElementById("password").value;
	var info = document.getElementById("info").value;

	str = 'login=' + login + '&password=' + pass + '&info=' + info;

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
		if (this.readyState === 4 && this.status === 200) {
			// success and response is received
			document.getElementById("queryResult").innerHTML = this.responseText;
		}
	}
	xhttp.open("POST", "Q5.jsp", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	console.log(str);
	xhttp.send(str);
});

document.getElementById("login").addEventListener('input', function () {
	var login = document.getElementById("login").value;

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
		if (this.readyState === 4 && this.status === 200) {
			// success and response is received
			document.getElementById("loginIdResult").innerHTML = this.responseText;
		}
	}
	xhttp.open("POST", "checkUser.jsp", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhttp.send('login=' + login);
});






