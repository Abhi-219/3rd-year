document.getElementById('submitForm').addEventListener('click', function(e){
	e.preventDefault();

	var res = document.getElementById('result');
	res.innerHTML = "";

	var login = document.getElementById("login").value;
	var oldPassword = document.getElementById("old-password").value;
	var newPassword = document.getElementById("new-password").value;
	var rPassword = document.getElementById("r-password").value;

	if(newPassword !== rPassword){
		res.innerHTML = "<p style=\"color: red;\">New Password doesn't match!</p>";
		return;
	}

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function(){
		if(this.readyState === 4 && this.status === 200){
			// success and response is received
			res.innerHTML = this.responseText;
		}
	}
	xhttp.open("POST", "Q10.jsp", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
	xhttp.send('login=' + login + "&oldPassword=" + oldPassword + "&newPassword=" + newPassword);
});
