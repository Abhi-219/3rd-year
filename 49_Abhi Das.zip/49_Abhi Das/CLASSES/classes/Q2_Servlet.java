import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class Q2_Servlet extends HttpServlet {
	
	public void service(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			String url="jdbc:mysql://localhost:3306/joins";
			String usrName = "root";
			String password = "Abhi@2000";
			String name = request.getParameter("name");
			
			String query = "select * from students where name like '%"+ name+"%';"  ;
			System.out.println(query);
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url, usrName, password);
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			int i=0;
			
			while ( rs.next() ) {
				String str = rs.getString(1) + "  " + rs.getString(2)+"  " + rs.getString(3) ;
				response.getWriter().println(str);
			}
						
			rs.close();
			conn.close();
					
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}
