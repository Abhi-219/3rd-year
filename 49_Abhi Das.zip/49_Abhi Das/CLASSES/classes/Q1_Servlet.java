import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class Q1_Servlet extends HttpServlet {
	
	public void service(HttpServletRequest request, HttpServletResponse response) {
		
		try {

			response.getWriter().println("<html><body>Hello World  from <br> <h4>Servlet</h4></body></html>");
					
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}
